#!/usr/bin/env bash
# deploy_smarkwm.sh
# Safe, opinionated deploy helper for smarkwm.online
# Usage (on the remote server as a user with sudo):
#   curl -O https://raw.githubusercontent.com/<you>/<repo>/main/deploy/deploy_smarkwm.sh
#   chmod +x deploy_smarkwm.sh
#   sudo ./deploy_smarkwm.sh
# Or copy it to the server and run with sudo.

set -euo pipefail
IFS=$'\n\t'

# --- CONFIGURE BEFORE RUNNING ---
# Edit these variables or export them in your shell before running.
REPO_URL="" # e.g. https://github.com/youruser/SimTk.git
DEPLOY_DIR="/home/ubuntu/SimTk"
DEPLOY_USER="ubuntu"
HOSTNAME="smarkwm.online"
EMAIL="" # required for certbot email

if [ -z "$REPO_URL" ]; then
  echo "ERROR: REPO_URL is empty. Edit the script and set REPO_URL to your repository URL." >&2
  exit 2
fi
if [ -z "$EMAIL" ]; then
  echo "ERROR: EMAIL is empty. Edit the script and set EMAIL to a contact email for certbot." >&2
  exit 2
fi

echo "[deploy] Starting deploy for $HOSTNAME into $DEPLOY_DIR"

# Update and install packages
apt update
apt upgrade -y
apt install -y nginx git software-properties-common curl build-essential

# Install Node 20 LTS
if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt install -y nodejs
fi

# Install pm2
if ! command -v pm2 >/dev/null 2>&1; then
  npm install -g pm2
fi

# Create deploy directory and fetch code
mkdir -p "$DEPLOY_DIR"
chown -R "$DEPLOY_USER":"$DEPLOY_USER" "$DEPLOY_DIR"
if [ ! -d "$DEPLOY_DIR/.git" ]; then
  sudo -u "$DEPLOY_USER" git clone "$REPO_URL" "$DEPLOY_DIR"
else
  cd "$DEPLOY_DIR"
  sudo -u "$DEPLOY_USER" git pull || true
fi

# Install app deps
cd "$DEPLOY_DIR"
sudo -u "$DEPLOY_USER" npm install --unsafe-perm

# Copy example prod env if present
if [ -f "$DEPLOY_DIR/smarkwm_env.txt" ] && [ ! -f "$DEPLOY_DIR/.env" ]; then
  cp "$DEPLOY_DIR/smarkwm_env.txt" "$DEPLOY_DIR/.env"
  echo "[deploy] Copied smarkwm_env.txt to .env — edit .env to set SESSION_SECRET and verify secrets." 
  chmod 600 .env
fi

# Ensure /var/www/letsencrypt exists
mkdir -p /var/www/letsencrypt
chown -R "$DEPLOY_USER":"$DEPLOY_USER" /var/www/letsencrypt

# Install certbot
apt install -y certbot python3-certbot-nginx

# Place nginx config provided in repo
NGINX_CONF_SRC="$DEPLOY_DIR/deploy/nginx/smarkwm.conf"
NGINX_CONF_DEST="/etc/nginx/sites-available/smarkwm"
if [ -f "$NGINX_CONF_SRC" ]; then
  cp "$NGINX_CONF_SRC" "$NGINX_CONF_DEST"
  ln -sf "$NGINX_CONF_DEST" /etc/nginx/sites-enabled/smarkwm
else
  echo "[warn] $NGINX_CONF_SRC not found — create nginx config manually or place file there." >&2
fi

# Test and reload nginx
nginx -t && systemctl reload nginx || true

# Open firewall (ufw)
if command -v ufw >/dev/null 2>&1; then
  ufw allow OpenSSH || true
  ufw allow 80/tcp || true
  ufw allow 443/tcp || true
  ufw --force enable || true
fi

# Obtain TLS cert
certbot --nginx -n --agree-tos -m "$EMAIL" -d "$HOSTNAME" -d "www.$HOSTNAME" || true

# Start app with pm2
PM2_ECOSYSTEM="$DEPLOY_DIR/deploy/pm2/ecosystem.config.js"
if [ -f "$PM2_ECOSYSTEM" ]; then
  pm2 start "$PM2_ECOSYSTEM" --update-env || pm2 start "$DEPLOY_DIR/server.js" --name simtk
  pm2 save
  pm2 startup systemd -u "$DEPLOY_USER" --hp "/home/$DEPLOY_USER" || true
else
  pm2 start "$DEPLOY_DIR/server.js" --name simtk || true
  pm2 save || true
fi

# Final checks
echo "[deploy] Final checks:"
curl -sS http://127.0.0.1:8080/status || echo "Cannot reach local app on 127.0.0.1:8080"
curl -I http://$HOSTNAME/status || true
curl -I https://$HOSTNAME/status || true

echo "[deploy] Done. If DNS and security groups are configured, your site should be reachable at https://$HOSTNAME"
